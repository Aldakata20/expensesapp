using ExpensesApi.Data;
using ExpensesApi.Dtos;
using ExpensesApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ExpensesApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ExpensesController : ControllerBase
{
    private readonly AppDbContext _db;

    public ExpensesController(AppDbContext db) => _db = db;

    // GET: api/expenses
    [HttpGet]
    public async Task<ActionResult<IEnumerable<object>>> GetAll()
    {
        var items = await _db.Expenses
            .AsNoTracking()
            .Include(e => e.Category)
            .OrderByDescending(e => e.Date)
            .Select(e => new
            {
                e.Id,
                e.Title,
                e.Amount,
                e.Date,
                Category = e.Category != null ? new { e.Category.Id, e.Category.Name } : null
            })
            .ToListAsync();

        return Ok(items);
    }

    // GET: api/expenses/5
    [HttpGet("{id:int}")]
    public async Task<ActionResult<object>> GetById(int id)
    {
        var item = await _db.Expenses
            .AsNoTracking()
            .Include(e => e.Category)
            .Where(e => e.Id == id)
            .Select(e => new
            {
                e.Id,
                e.Title,
                e.Amount,
                e.Date,
                Category = e.Category != null ? new { e.Category.Id, e.Category.Name } : null
            })
            .FirstOrDefaultAsync();

        return item is null ? NotFound() : Ok(item);
    }

    // POST: api/expenses
    [HttpPost]
    public async Task<ActionResult<Expense>> Create(ExpenseCreateDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Title))
            return BadRequest("Title is required.");

        var categoryExists = await _db.Categories.AnyAsync(c => c.Id == dto.CategoryId);
        if (!categoryExists)
            return BadRequest("Invalid CategoryId.");

        var entity = new Expense
        {
            Title = dto.Title.Trim(),
            Amount = dto.Amount,
            Date = dto.Date == default ? DateTime.UtcNow : dto.Date,
            CategoryId = dto.CategoryId
        };

        _db.Expenses.Add(entity);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = entity.Id }, entity);
    }

    // PUT: api/expenses/5
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, ExpenseUpdateDto dto)
    {
        var entity = await _db.Expenses.FirstOrDefaultAsync(e => e.Id == id);
        if (entity is null) return NotFound();

        var categoryExists = await _db.Categories.AnyAsync(c => c.Id == dto.CategoryId);
        if (!categoryExists)
            return BadRequest("Invalid CategoryId.");

        entity.Title = dto.Title.Trim();
        entity.Amount = dto.Amount;
        entity.Date = dto.Date == default ? entity.Date : dto.Date;
        entity.CategoryId = dto.CategoryId;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    // DELETE: api/expenses/5
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var entity = await _db.Expenses.FirstOrDefaultAsync(e => e.Id == id);
        if (entity is null) return NotFound();

        _db.Expenses.Remove(entity);
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
