using ExpensesApi.Models;

namespace ExpensesApi.Data;

public static class DbSeeder
{
    public static void Seed(AppDbContext db)
    {
        if (db.Categories.Any()) return;

        var categories = new List<Category>
        {
            new() { Id = 1, Name = "Food" },
            new() { Id = 2, Name = "Fuel" },
            new() { Id = 3, Name = "Supplies" },
            new() { Id = 4, Name = "Other" }
        };

        db.Categories.AddRange(categories);

        db.Expenses.AddRange(
            new Expense { Id = 1, Title = "Lunch", Amount = 15.50m, Date = DateTime.UtcNow.AddDays(-2), CategoryId = 1 },
            new Expense { Id = 2, Title = "Gas", Amount = 62.10m, Date = DateTime.UtcNow.AddDays(-1), CategoryId = 2 },
            new Expense { Id = 3, Title = "Materials", Amount = 120.00m, Date = DateTime.UtcNow, CategoryId = 3 }
        );

        db.SaveChanges();
    }
}
