namespace ExpensesApi.Dtos;

public record CategoryCreateDto(string Name);
public record CategoryUpdateDto(string Name);
