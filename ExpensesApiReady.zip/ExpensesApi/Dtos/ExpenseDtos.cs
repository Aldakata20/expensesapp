namespace ExpensesApi.Dtos;

public record ExpenseCreateDto(
    string Title,
    decimal Amount,
    DateTime Date,
    int CategoryId
);

public record ExpenseUpdateDto(
    string Title,
    decimal Amount,
    DateTime Date,
    int CategoryId
);
