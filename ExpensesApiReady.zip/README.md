# ExpensesApi (ASP.NET Web API)

Simple ASP.NET Web API project with CRUD endpoints (GET/POST/PUT/DELETE) using Entity Framework Core **InMemory** database.

## Requirements
- .NET 8 SDK

## Run
```bash
cd ExpensesApi
dotnet restore
dotnet run
```

Open Swagger:
- https://localhost:7189/swagger
- http://localhost:5189/swagger

## Endpoints
### Categories
- GET `/api/categories`
- GET `/api/categories/{id}`
- POST `/api/categories`
- PUT `/api/categories/{id}`
- DELETE `/api/categories/{id}`

### Expenses
- GET `/api/expenses`
- GET `/api/expenses/{id}`
- POST `/api/expenses`
- PUT `/api/expenses/{id}`
- DELETE `/api/expenses/{id}`

## Example JSON
Create category:
```json
{ "name": "Tools" }
```

Create expense:
```json
{
  "title": "Dehumidifier filter",
  "amount": 39.99,
  "date": "2026-02-01T12:00:00Z",
  "categoryId": 3
}
```
